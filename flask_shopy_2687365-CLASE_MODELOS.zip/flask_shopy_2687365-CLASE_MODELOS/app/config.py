class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:admin1234@localhost:3311/flask_shopy_2687365'
    SECRET_KEY = 'elpepe'